#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>

int read_file ( char *buffer, FILE *input_file)
{
	char *buffer_pointer = buffer;
	int characters_read = 0;
	int character_in = 0;
	while ( (character_in = fgetc ( input_file )) != EOF )
	{
		*buffer++ = character_in;
		characters_read++;
		if ( character_in == EOF)
		{
			return ( EOF );
		}
		else if ( character_in == 10 )
		{
			return ( characters_read );
		}
	}
}

int main ( int argc, char *argv [] )
{
	FILE *fp_input;
	FILE *fp_output;
	char output_file_name [256];

	if ( argc < 2)
	{
		printf ( "Please supply an input file name\n" );
		exit(1);
	}

	fp_input = fopen ( argv [1], "r");
	if (fp_input == NULL)
	{
		printf("Cannot open input file\n");
		exit (1);
	}

	sprintf ( output_file_name, "filtered_%s", argv [1] );


	fp_output = fopen ( output_file_name, "w");
	if (fp_output == NULL)
	{
		printf("Cannot open output file\n");
		exit (1);
	}

	char buffer1  [256] ;
	char buffer2  [256] ;
	char *start_in_buffer  = buffer1;
	char *start_out_buffer = buffer2;
	char *in_pointer  = start_in_buffer;
	char *out_pointer = start_out_buffer;
	int Buffer_size = 256;
	int line_length;
	int character_index;

	line_length = read_file ( out_pointer, fp_input );
	/* The first line of input is the column headings */
	fwrite ( out_pointer, 1, line_length, fp_output );

	line_length = read_file ( in_pointer, fp_input );
	character_index = line_length;
	int line_count = 2;

	while ( character_index != EOF )
	{
		while ( character_index > 0 )
		{
			if ( (*in_pointer == 10) || (*out_pointer == 10 ) || (*in_pointer != *out_pointer) || (character_index <= 0) )
			{
				if ( *in_pointer != *out_pointer ) /* The 2 lines are different */
				{
					in_pointer = start_in_buffer;
					fwrite ( in_pointer, 1, line_length, fp_output );
					if ( start_in_buffer == buffer1 )
					{
						start_in_buffer  = buffer2;
						start_out_buffer = buffer1;
						in_pointer  = buffer2;
						out_pointer = buffer1;
					}
					else
					{
						start_in_buffer  = buffer1;
						start_out_buffer = buffer2;
						in_pointer  = buffer1;
						out_pointer = buffer2;
					}
				}
				in_pointer  = start_in_buffer;
				line_length = read_file ( in_pointer, fp_input );
				in_pointer  = start_in_buffer;
				out_pointer = start_out_buffer;
				character_index = line_length;
				line_count++;
			}
			else
			{
				in_pointer++;
				out_pointer++;
				character_index--;
			}
		}
	}
	fclose (fp_output);
	fclose (fp_input);
}
