#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>

int read_file ( char *buffer, FILE *input_file)
{
	char *buffer_pointer = buffer;
	int characters_read = 0;
	int character_in = 0;
	while ( (character_in = fgetc ( input_file )) != EOF )
	{
		*buffer++ = character_in;
		characters_read++;
		if ( character_in == EOF)
		{
			return ( EOF );
		}
		else if ( character_in == '\n' )
		{
			return ( characters_read );
		}
	}
}

int write_line ( char *buffer, FILE *output_file)
{
        char *buffer_pointer = buffer;
	int EOL = '\n';
        while ( *buffer_pointer != EOL )
        {
                fprintf ( output_file, "%c", *buffer_pointer++ );
	}
        fprintf ( output_file, "%c", EOL );
}

int main ( int argc, char *argv [] )
{
	FILE* fp_input;
	FILE* fp_output;
	char output_file_name [256];

	if ( argc < 2)
		printf ( "Please supply an input file name\n" );

	fp_input = fopen ( argv [1], "r");
	if (fp_input == NULL)
	{
		printf("Cannot open input file\n");
		exit (1);
	}

	sprintf ( output_file_name, "modified_%s", argv [1] );
	/* printf ("Output file name is %s\n", output_file_name ); */


	fp_output = fopen ( output_file_name, "w");
	if (fp_output == NULL)
	{
		printf("Cannot open output file\n");
		exit (1);
	}

	char line_in  [256] ;
	/* char line_out [256]; */
	char is_attack = '1';
	int num_in = 0;
	int last_index = 0;
	int EOL = '\n';

	/* The first line of input is the column headings */
	num_in = read_file ( line_in, fp_input );
	write_line ( line_in, fp_output );

	num_in = read_file ( line_in, fp_input );
	while ( num_in != EOF )
	{
		for (int i = 0; i < 220; i++)
		{
			if ( line_in [i] == EOL )
			{
				last_index = i-1;
				break;
			}
		}
		if ( line_in [last_index] == is_attack )
		{
			write_line ( line_in, fp_output );
		}
		num_in = read_file ( line_in, fp_input );
	}

	fclose (fp_output);
	fclose (fp_input);
}
