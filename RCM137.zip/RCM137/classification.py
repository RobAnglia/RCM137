#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Aug 29 12:14:12 2019

@author: hananhindy
Modified RCMorley RCM137
"""
import pandas as pd
import numpy as np
import os
import argparse
import sys                      #RCM137
import matplotlib.pyplot as plt #RCM137
import time                     #RCM137
import random                   #RCM137

from sklearn.preprocessing import OneHotEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC, LinearSVC
from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split, StratifiedKFold
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay  #RCM137
from pathlib import Path                                              #RCM137

# Helper Function
def str2bool(v):
    if v.lower() in ('yes', 'true', 't', 'y', '1'):
        return True
    elif v.lower() in ('no', 'false', 'f', 'n', '0'):
        return False
    else:
        raise argparse.ArgumentTypeError('Boolean value expected.')

#protocols = ['ARP', 'CDP', 'CLDAP', 'DATA', 'DNS', 'DTLS', 'DTP', 'ECHO', 'ICMP', 'ISAKMP','MDNS', 'NAT-PMP', 'NBNS', 'NFS', 'NTP', 'PORTMAP', 'RADIUS', 'RIP', 'SRVLOC', 'SNMP',  'SSH', 'STP', 'TCP', 'UDP', 'XDMCP', 'MQTT', 'MPEG_PMT', 'MP2T', 'MPEG_PAT', 'DVB_SDT']
protocols = [['ARP', 'CDP', 'CLDAP', 'DATA', 'DNS', 'DTLS', 'DTP', 'ECHO', 'ICMP', 'ISAKMP','MDNS', 'NAT-PMP', 'NBNS', 'NFS', 'NTP', 'PORTMAP', #RCM137
              'RADIUS', 'RIP', 'SRVLOC', 'SNMP',  'SSH', 'STP', 'TCP', 'UDP', 'XDMCP', 'MQTT', 'MPEG_PMT', 'MP2T', 'MPEG_PAT', 'DVB_SDT']]      #RCM137
#label_encoder = LabelEncoder().fit(protocols)

one_hot_encoder = None

global logistic_y_true          #RCM137
logistic_y_true = []            #RCM137
global logistic_y_predictions   #RCM137
logistic_y_predictions = []     #RCM137
global knn_y_true               #RCM137
knn_y_true = []                 #RCM137
global knn_y_predictions        #RCM137
knn_y_predictions = []          #RCM137
global rbf_y_true               #RCM137
rbf_y_true = []                 #RCM137
global rbf_y_predictions        #RCM137
rbf_y_predictions = []          #RCM137
global naive_y_true             #RCM137
naive_y_true = []               #RCM137
global naive_y_predictions      #RCM137
naive_y_predictions = []        #RCM137
global decision_tree_y_true             #RCM137
decision_tree_y_true = []               #RCM137
global decision_tree_y_predictions      #RCM137
decision_tree_y_predictions = []        #RCM137
global random_forest_y_true             #RCM137
random_forest_y_true = []               #RCM137
global random_forest_y_predictions      #RCM137
random_forest_y_predictions = []        #RCM137
global linear_svc_y_true                #RCM137
linear_svc_y_true = []                  #RCM137
global linear_svc_y_predictions         #RCM137
linear_svc_y_predictions = []           #RCM137

#RCM137 def load_file(path, mode, is_attack = 1, label = 1, folder_name='Bi/', sliceno = 0, verbose = True):
def load_file(path, mode, is_attack = 1, label = 1, folder_name='Bi/', sliceno = 0, verbose = True, trace = False, balanced = True, NoHot = False): #RCM137
    #global label_encoder
    global one_hot_encoder
    number_of_lines = 1                                         #RCM137
    number_of_lines_sparta = 20676121                           #RCM137
    number_of_lines_mqtt   = 10045307                           #RCM137
    #attacker_ips = ['192.168.2.5']
    
    columns_to_drop_packet = ['timestamp', 'src_ip', 'dst_ip']
    columns_to_drop_uni = ['proto', 'ip_src', 'ip_dst']
    columns_to_drop_bi = ['proto', 'ip_src', 'ip_dst']
    
    file_name = Path(path).name                                                     #RCM137
    if trace:                                                                       #RCM137
        sys.stderr.write (f'\nStart of load routine\n')                             #RCM137
        sys.stderr.write (f'size of {file_name} file is {os.path.getsize(path)}\n') #RCM137
        p1 = os.path.getsize(path)//10 ** 9                                         #RCM137
        sys.stderr.write (f'p1 = {p1}\n')                                           #RCM137

    if os.path.getsize(path)//10 ** 9 > 0:
        x = np.zeros((0,0))
        if file_name == 'preprocessed_sparta.csv':                                  #RCM137
            number_of_lines = number_of_lines_sparta                                #RCM137
        elif file_name == 'preprocessed_mqtt_bruteforce.csv':                       #RCM137
            number_of_lines = number_of_lines_mqtt                                  #RCM137
        number_of_chunks = number_of_lines / 10 ** 6                                #RCM137
        chunk_number = 0                                                            #RCM137
        for chunk in pd.read_csv(path, chunksize=10 ** 6):
            chunk_number = chunk_number + 1                                                     #RCM137
            if verbose:                                                                         #RCM137
                sys.stderr.write (f'Read chunk {chunk_number} of {number_of_chunks} chunks \n') #RCM137
            chunk.drop(columns = columns_to_drop_packet, inplace = True)
            chunk = chunk[chunk.columns.drop(list(chunk.filter(regex='mqtt')))]
                                     
            chunk = chunk.fillna(-1)
        
            with open(folder_name + 'instances_count.csv','a') as f:
                f.write('{}, {} \n'.format(path, chunk.shape[0]))
                
#RCM137     x_temp = chunk.loc[chunk['is_attack'] == is_attack]   
            chunk = chunk.loc[chunk['is_attack'] == is_attack]                      #RCM137
#RCM137     x_temp.drop('is_attack', axis = 1, inplace = True)
            chunk.drop('is_attack', axis = 1, inplace = True)                       #RCM137
            #x_temp['protocol'] = label_encoder.transform(x_temp['protocol'])
            if not NoHot:
                if one_hot_encoder == None:
#RCM137         one_hot_encoder = OneHotEncoder(categorical_features=[0], n_values=30)
                    one_hot_encoder = OneHotEncoder( categories = protocols, sparse_output = False )    #RCM137
#RCM137         x_temp = one_hot_encoder.fit_transform(x_temp).toarray()
#RCM137     else:
#RCM137         x_temp = one_hot_encoder.transform(x_temp).toarray()
                transformed_dataset =  pd.DataFrame(one_hot_encoder.fit_transform( chunk [['protocol']] ),              #RCM137
                                                    columns = one_hot_encoder.get_feature_names_out(),                  #RCM137
                                                    index = chunk.index)                                                #RCM137
            chunk.drop('protocol', axis=1, inplace=True)                        #RCM137
            if not NoHot:
                chunk = pd.concat ( [ transformed_dataset, chunk ], axis = 1 )  #RCM137
            x_temp = chunk.values                                               #RCM137

            x_temp = np.unique(x_temp, axis = 0)
            
            if x.size == 0:
                x = x_temp
            else:
                x = np.concatenate((x, x_temp), axis = 0)
                x = np.unique(x, axis = 0)
    else:
        dataset = pd.read_csv(path)
        if trace:                                                                                       #RCM137
            sys.stderr.write (f'1111111111111111111111111111111 Type of dataset is {type(dataset)}\n')  #RCM137
            sys.stderr.write (f'Absent values are\n{dataset.isna().sum()}\n')                           #RCM137
            sys.stderr.write (f'--------------------------------------------------------\n')            #RCM137
            sys.stderr.write (f'{file_name} dataset as read in\n {dataset.describe()}\n')               #RCM137
            sys.stderr.write (f'{file_name} dataset as read in\n {dataset.head()}\n')                   #RCM137

        if mode == 1 or mode == 2:
            dataset = dataset.loc[dataset['is_attack'] == is_attack]
#            if is_attack == 0:
#                dataset = dataset.loc[operator.and_(dataset['ip_src'].isin(attacker_ips) == False, dataset['ip_dst'].isin(attacker_ips) == False)]
#            else:
#                dataset = dataset.loc[operator.or_(dataset['ip_src'].isin(attacker_ips), dataset['ip_dst'].isin(attacker_ips))]
#            
            if trace:                                                                                                               #RCM137
                sys.stderr.write (f'22222222222222222222222222222222222 Type of dataset is {type(dataset)}\n')                      #RCM137
                sys.stderr.write (f'{file_name} dataset after filtering with is_attack equal to {is_attack}\n {dataset.head()}')    #RCM137

        if mode == 0:
#RCM137     dataset.drop(columns=[columns_to_drop_packet], inplace = True)
            dataset.drop(columns=columns_to_drop_packet, inplace = True)                                    #RCM137
            if trace:                                                                                       #RCM137
                sys.stderr.write (f'22222222222222222222222 Type of dataset is {type(dataset)}\n')          #RCM137
                sys.stderr.write (f'{file_name} dataset after removing columns\n {dataset.head()}\n')       #RCM137
            dataset = dataset[dataset.columns.drop(list(dataset.filter(regex='mqtt')))]
            if trace:                                                                                       #RCM137
                sys.stderr.write (f'3333333333333333333333 Type of dataset is {type(dataset)}\n')           #RCM137
                sys.stderr.write (f'{file_name} dataset after removing mqtt columns\n {dataset.head()}\n')  #RCM137
                sys.stderr.write (f'\n')
        elif mode == 1:
            dataset.drop(columns = columns_to_drop_uni, inplace = True)
            dataset.drop('is_attack', axis=1, inplace=True)                                                         #RCM137
            if trace:                                                                                               #RCM137
                sys.stderr.write (f'3333333333333333333333333333333333333 Type of Dataset is {type(dataset)}\n')    #RCM137
                sys.stderr.write (f'Final {file_name} dataset after removing columns\n {dataset.head()}\n')         #RCM137
        elif mode == 2:
            dataset.drop(columns = columns_to_drop_bi, inplace = True)
            dataset.drop('is_attack', axis=1, inplace=True)                                                         #RCM137
            if trace:                                                                                               #RCM137
                sys.stderr.write (f'3333333333333333333333333333333333333 Type of dataset is {type(dataset)}\n')    #RCM137
                sys.stderr.write (f'Final {file_name} dataset afer removing columns\n {dataset.head()}\n')          #RCM137

        if verbose:                 
            print(dataset.columns)
            
        if trace:                                                                                           #RCM137
            sys.stderr.write (f'Absent values before fillna are\n{dataset.isna().sum()}\n')                 #RCM137

        dataset = dataset.fillna(-1)
               
        if trace:                                                                                           #RCM137
            sys.stderr.write (f'Absent values after fillna are\n{dataset.isna().sum()}\n')                  #RCM137

        if mode == 0:
            if trace:                                                                                                                       #RCM137
                sys.stderr.write (f'Type of dataset is {type(dataset)}\n')                                                                  #RCM137
                sys.stderr.write (f'{file_name} dataset before filtering with is_attack equal to {is_attack}\n  {dataset.describe()}\n')    #RCM137
                sys.stderr.write (f'{file_name} dataset before filtering with is_attack equal to {is_attack}\n {dataset.head()}\n')         #RCM137
#RCM137     x = dataset.loc[dataset['is_attack'] == is_attack]   
            dataset = dataset.loc[dataset['is_attack'] == is_attack]                                                                    #RCM137
            if trace:                                                                                                                   #RCM137
                sys.stderr.write (f'44444444444444444444444444444 Type of dataset is {type(dataset)}\n')                                #RCM137
                sys.stderr.write (f'{file_name} dataset after filtering with is_attack equal to {is_attack}\n  {dataset.describe()}\n') #RCM137
                sys.stderr.write (f'{file_name} dataset after filtering with is_attack equal to {is_attack}\n {dataset.head()}\n')      #RCM137
            dataset.drop('is_attack', axis=1, inplace=True)                                                                             #RCM137
            if trace:                                                                                           #RCM137
                sys.stderr.write (f'55555555555555555555555555555555555 Type of dataset is {type(dataset)}\n')  #RCM137
                sys.stderr.write (f'{file_name} dataset after dropping is_attack\n {dataset.head()}\n')         #RCM137
                sys.stderr.write (f'{file_name} types are\n{dataset.dtypes}\n')                                 #RCM137
            #x['protocol'] = label_encoder.transform(x['protocol'])
            if not NoHot:                                                                                  #RCM137
                if one_hot_encoder == None:
#RCM137         one_hot_encoder = OneHotEncoder(categorical_features=[0], n_values=30)
#RCM137         x = one_hot_encoder.fit_transform(x).toarray()
                    one_hot_encoder = OneHotEncoder( categories = protocols, sparse_output = False )               #RCM137
#RCM137     else:
#RCM137         x = one_hot_encoder.transform(x).toarray()
                transformed_dataset = pd.DataFrame( one_hot_encoder.fit_transform( dataset [['protocol']] ),       #RCM137
                                                   columns = one_hot_encoder.get_feature_names_out(),              #RCM137
                                                   index = dataset.index )                                         #RCM137
                if trace:                                                                                                               #RCM137
                    sys.stderr.write (f'66666666666666666666666666666666 Type of transformed_dataset is {type(transformed_dataset)}\n') #RCM137
                    sys.stderr.write (f'{file_name} transformed_dataset after one hot encoding is\n {transformed_dataset.head()}\n')    #RCM137
                    
            dataset.drop('protocol', axis=1, inplace=True)                                                  #RCM137
            if trace:                                                                                       #RCM137
                sys.stderr.write (f'77777777777777777777777777777777 Type of dataset is {type(dataset)}\n') #RCM137
                sys.stderr.write (f'{file_name} dataset after dropping protocol\n {dataset.head()}\n')      #RCM137

            if not NoHot:
                dataset = pd.concat ( [ transformed_dataset, dataset ], axis = 1 )                              #RCM137
                
                if trace:                                                                                                       #RCM137
                    sys.stderr.write (f'8888888888888888888888888888888888888 Categories are\n{one_hot_encoder.categories_}\n') #RCM137
                    sys.stderr.write (f'Feature names are\n{one_hot_encoder.get_feature_names_out()}\n')                        #RCM137
                    sys.stderr.write (f'Type of dataset is {type(dataset)}\n')                                                  #RCM137
                    sys.stderr.write (f'{file_name} dataset after one hot encoding is\n {dataset.head()}\n')                    #RCM137
                
            x = dataset.values                                                                                              #RCM137
            
            if trace:                                                                                                       #RCM137
                sys.stderr.write (f'9999999999999999999999999999999999999999999999 Type of x is {type(x)}\n')               #RCM137
        else:
            if trace:                                                                                                               #RCM137
                sys.stderr.write (f'444444444444444444444444444444444444444444444444444444 Type of dataset is {type(dataset)}\n')   #RCM137
                
            x = dataset.values
            
            if trace:                                                                                                       #RCM137
                sys.stderr.write (f'5555555555555555555555555555555555555555555555555555555 Type of x is {type(x)}\n')      #RCM137

    with open(folder_name + 'instances_count.csv','a') as f:
        f.write('all, {}, {} \n'.format(path, x.shape[0]))

    if trace:                                                                                                       #RCM137
        sys.stderr.write (f'Type of x is {type(x)}\n')                                                              #RCM137
        sys.stderr.write (f'x shape before removing duplicates {x.shape}\n')                                        #RCM137
        sys.stderr.write ("\n----------------------------------------------------------------------------------\n") #RCM137

    x = np.unique(x, axis = 0)
    if trace:                                                                                       #RCM137
        sys.stderr.write (f'10101010101010101010101010101010101010101010 Type of x is {type(x)}\n') #RCM137
        sys.stderr.write (f'x shape after removing duplicates {x.shape}\n')                         #RCM137

    with open(folder_name + 'instances_count.csv','a') as f:
        f.write('unique, {}, {} \n'.format(path, x.shape[0]))

    if (mode == 1 and x.shape[0] > 100000) or (mode == 2 and x.shape[0] > 50000):
        if trace:                                           #RCM137
            sys.stderr.write ("Position 15\n")              #RCM137
        temp = x.shape[0] // 10
        start = sliceno * temp
        end = start + temp - 1 
        x = x[start:end,:] 
        with open(folder_name + 'instances_count.csv','a') as f:
            f.write('Start, {}, End, {} \n'.format(start, end))
    elif mode == 0:
        if trace:                                           #RCM137
            sys.stderr.write (f'shape is {x.shape}\n')      #RCM137
            sys.stderr.write ("Position 16\n")              #RCM137
        if x.shape[0] > 15000000:
            if trace:                                       #RCM137
                sys.stderr.write ("Position 17\n")          #RCM137
            temp = x.shape[0] // 400
            start = sliceno * temp
            end = start + temp - 1 
            x = x[start:end,:] 
            with open(folder_name + 'instances_count.csv','a') as f:
                f.write('Start, {}, End, {} \n'.format(start, end))
        elif x.shape[0] > 10000000:
            if trace:                                       #RCM137
                sys.stderr.write ("Position 18\n")          #RCM137
            temp = x.shape[0] // 200
            start = sliceno * temp
            end = start + temp - 1 
            x = x[start:end,:] 
            with open(folder_name + 'instances_count.csv','a') as f:
                f.write('Start, {}, End, {} \n'.format(start, end))
        elif x.shape[0] > 100000:
            if trace:                                       #RCM137
                sys.stderr.write ("Position 19\n")          #RCM137
            temp = x.shape[0] // 10
            start = sliceno * temp
            end = start + temp - 1 
            x = x[start:end,:] 
            with open(folder_name + 'instances_count.csv','a') as f:
                f.write('Start, {}, End, {} \n'.format(start, end))

    reshape_x = False                               #RCM137
    if balanced:                                    #RCM137
        reshape_x = True                            #RCM137
        if mode == 0:                               #RCM137
            rows = 16701                            #RCM137
            if NoHot:                               #RCM137
                columns = 17                        #RCM137
            else:                                   #RCM137
                columns = 47                        #RCM137
            if file_name == 'filtered_scan_A.csv':  #RCM137
                reshape_x = False                   #RCM137
        elif mode == 1:                             #RCM137
            rows = 2233                             #RCM137
            columns = 15                            #RCM137
            if file_name == 'uniflow_scan_sU.csv':  #RCM137
                reshape_x = False                   #RCM137
        elif mode == 2:                             #RCM137
            rows = 2001                             #RCM137
            columns = 28                            #RCM137
            if file_name == 'biflow_scan_A.csv':    #RCM137
                reshape_x = False                   #RCM137
        else:                                       #RCM137
            exit (-1)

    if reshape_x:                                               #RCM137
        x_rows = x.shape[0]                                     #RCM137
        if trace:                                               #RCM137
            sys.stderr.write (f'x_rows is {x_rows}\n')          #RCM137
        used = np.full ( x_rows, False, dtype = bool )          #RCM137
        x_reshaped = np.arange( rows * columns, dtype=np.float64).reshape( rows, columns )  #RCM137
        count = 0                                               #RCM137
        while count < rows:                                     #RCM137
            index = random.randrange(start = 0, stop = x_rows)  #RCM137
            if used [ index ] == False:                         #RCM137
                used [ index ] = True                           #RCM137
                x_reshaped [count] = x [index]                  #RCM137
                count = count + 1                               #RCM137
        x = x_reshaped                                          #RCM137
        if trace:                                               #RCM137
            sys.stderr.write (f'x reshaped is {x.shape[0]}\n')  #RCM137

    if trace:                                               #RCM137
        sys.stderr.write ("Position 20\n")                  #RCM137
        sys.stderr.write (f'x shape is {x.shape}\n')        #RCM137
        sys.stderr.write (f'x ndim is {x.ndim}\n')          #RCM137
        sys.stderr.write (f'x dtype is {x.dtype}\n')        #RCM137
            
    y = np.full(x.shape[0], label)
    
    if trace:                                               #RCM137
        sys.stderr.write ("Position 21\n")                  #RCM137
        sys.stderr.write (f'y shape is {y.shape}\n')        #RCM137
        sys.stderr.write (f'y ndim is {y.ndim}\n')          #RCM137
        sys.stderr.write (f'y dtype is {y.dtype}\n')        #RCM137
        
    with open(folder_name + 'instances_count.csv','a') as f:
        f.write('slice, {}, {} \n'.format(path, x.shape[0]))
        
    if trace:                                               #RCM137
        sys.stderr.write ("Position 22\n")                  #RCM137
        
    return x, y

def classify_sub(classifier, x_train, y_train, x_test, y_test, cm_file_name, summary_file_name, classifier_name, verbose = True):
    classifier.fit(x_train, y_train)
    pred = classifier.predict(x_test)

    global logistic_y_true              #RCM137
    global logistic_y_predictions       #RCM137
    global knn_y_true                   #RCM137
    global knn_y_predictions            #RCM137
    global rbf_y_true                   #RCM137
    global rbf_y_predictions            #RCM137
    global naive_y_true                 #RCM137
    global naive_y_predictions          #RCM137
    global decision_tree_y_true         #RCM137
    global decision_tree_y_predictions  #RCM137
    global random_forest_y_true         #RCM137
    global random_forest_y_predictions  #RCM137
    global linear_svc_y_true            #RCM137
    global linear_svc_y_predictions     #RCM137
    
    match classifier_name:
        case "Logistic":                                                        #RCM137
            logistic_y_true = np.append( logistic_y_true, y_test )              #RCM137
            logistic_y_predictions = np.append( logistic_y_predictions, pred )  #RCM137
        case "KNN":                                                             #RCM137
            knn_y_true = np.append( knn_y_true, y_test )                        #RCM137
            knn_y_predictions = np.append( knn_y_predictions, pred )            #RCM137
        case "RBF":                                                             #RCM137
            rbf_y_true = np.append( rbf_y_true, y_test )                        #RCM137
            rbf_y_predictions = np.append( rbf_y_predictions, pred )            #RCM137
        case "Naive":                                                           #RCM137
            naive_y_true = np.append( naive_y_true, y_test )                    #RCM137
            naive_y_predictions = np.append( naive_y_predictions, pred )        #RCM137
        case "Decision Tree":                                                   #RCM137
            decision_tree_y_true = np.append( decision_tree_y_true, y_test )                #RCM137
            decision_tree_y_predictions = np.append( decision_tree_y_predictions, pred )    #RCM137
        case "Random Forest":                                                               #RCM137
            random_forest_y_true = np.append( random_forest_y_true, y_test )                #RCM137
            random_forest_y_predictions = np.append( random_forest_y_predictions, pred )    #RCM137
        case "Linear SVC":                                                                  #RCM137
            linear_svc_y_true = np.append( linear_svc_y_true, y_test )                      #RCM137
            linear_svc_y_predictions = np.append( linear_svc_y_predictions, pred )          #RCM137
        case _:                                                                             #RCM137
            print ("Illegal Option\n")                                                      #RCM137
            exit (-1)                                                                       #RCM137

    cm = pd.crosstab(y_test, pred)
    cm.to_csv(cm_file_name)    
    
    pd.DataFrame(classification_report(y_test, pred, output_dict = True)).transpose().to_csv(summary_file_name)
    
    if verbose:
#RCM137        print(classifier_name + ' Done.\n')
        print(classifier_name + ' Done.')               #RCM137
    
    del classifier
    del pred
    del cm
    
def classify(random_state, x_train, y_train, x_test, y_test, folder_name, prefix = "", verbose = True):
    confusion_matrix_folder = os.path.join(folder_name, 'Confusion_Matrix/') 
    summary_folder =  os.path.join(folder_name, 'Summary/') 

    if os.path.isdir(confusion_matrix_folder) == False:
            os.mkdir(confusion_matrix_folder)
    if os.path.isdir(summary_folder) == False:
            os.mkdir(summary_folder)

    from sklearn.preprocessing import StandardScaler    #RCM137   
    scaler = StandardScaler().fit(x_train)              #RCM137
    X_train_scaled = scaler.transform(x_train)          #RCM137
    X_test_scaled  = scaler.transform(x_test)           #RCM137

    # 1- Linear
#RCM137 linear_classifier = LogisticRegression(random_state = random_state)
    logistic_classifier = LogisticRegression(max_iter = 10000000, n_jobs = -1, random_state = random_state) #RCM137
    classify_start_time = time.time()                                                                       #RCM137
#RCM137    classify_sub(linear_classifier, 
    classify_sub(logistic_classifier, 
#RCM137          x_train, y_train, 
                 X_train_scaled, y_train,           #RCM137
#RCM137          x_test, y_test, 
                 X_test_scaled, y_test,             #RCM137
                 confusion_matrix_folder + prefix + '_cm_linear.csv', 
                 summary_folder + prefix + '_summary_linear.csv',
                 'Logistic',
                 verbose)
    elapsed_time = time.time() - classify_start_time                                                        #RCM137
    if verbose:                                                                                             #RCM137
        print('logistic_classifier execution time:', time.strftime("%H:%M:%S", time.gmtime(elapsed_time)))  #RCM137
       
    # 2- KNN
#RCM137 knn_classifier = KNeighborsClassifier()
    knn_classifier = KNeighborsClassifier(n_jobs = -1)  #RCM137
    classify_start_time = time.time()                   #RCM137
    classify_sub(knn_classifier, 
#RCM137          x_train, y_train,
                 X_train_scaled, y_train,           #RCM137
#RCM137          x_test, y_test,
                 X_test_scaled, y_test,             #RCM137
                 confusion_matrix_folder + prefix + '_cm_knn.csv',
                 summary_folder + prefix + '_summary_knn.csv',
                 'KNN',
                 verbose)
    elapsed_time = time.time() - classify_start_time                                                        #RCM137
    if verbose:                                                                                             #RCM137
        print('knn_classifier execution time:', time.strftime("%H:%M:%S", time.gmtime(elapsed_time)))       #RCM137

    #3- RBF SVM
    kernel_svm_classifier = SVC(kernel = 'rbf', random_state = random_state, gamma='scale')
    classify_start_time = time.time()                                                                       #RCM137
    classify_sub(kernel_svm_classifier, 
#RCM137          x_train, y_train,
                 X_train_scaled, y_train,           #RCM137
#RCM137          x_test, y_test,
                 X_test_scaled, y_test,             #RCM137
                 confusion_matrix_folder + prefix + '_cm_kernel_svm.csv',
                 summary_folder + prefix + '_summary_kernel_svm.csv',
#RCM137          'SVM',
                 'RBF',         #RCM137
                 verbose)
    elapsed_time = time.time() - classify_start_time                                                            #RCM137
    if verbose:                                                                                                 #RCM137
        print('kernel_svm_classifier execution time:', time.strftime("%H:%M:%S", time.gmtime(elapsed_time)))    #RCM137

    #4- Naive Bayes
    naive_classifier = GaussianNB()
    classify_start_time = time.time()    #RCM137
    classify_sub(naive_classifier, 
#RCM137          x_train, y_train,
                 X_train_scaled, y_train,           #RCM137
#RCM137          x_test, y_test,
                 X_test_scaled, y_test,             #RCM137
                 confusion_matrix_folder + prefix + '_cm_naive.csv',
                 summary_folder + prefix + '_summary_naive.csv',
                 'Naive',
                 verbose)
    elapsed_time = time.time() - classify_start_time                                                     #RCM137
    if verbose:                                                                                          #RCM137
        print('naive_classifier execution time:', time.strftime("%H:%M:%S", time.gmtime(elapsed_time)))  #RCM137

    #5- Decision Tree
    decision_tree_classifier = DecisionTreeClassifier(criterion = 'entropy', random_state = random_state)
    classify_start_time = time.time()    #RCM137
    classify_sub(decision_tree_classifier, 
#RCM137          x_train, y_train,
                 X_train_scaled, y_train,           #RCM137
#RCM137          x_test, y_test,
                 X_test_scaled, y_test,             #RCM137
                 confusion_matrix_folder + prefix + '_cm_decision_tree.csv',
                 summary_folder + prefix + '_summary_decision_tree.csv',
                 'Decision Tree',
                 verbose)
    elapsed_time = time.time() - classify_start_time                                                            #RCM137
    if verbose:                                                                                                 #RCM137
        print('decision_tree_classifier execution time:', time.strftime("%H:%M:%S", time.gmtime(elapsed_time))) #RCM137
    
    #6- Random Forest
#RCM137 random_forest_classifier = RandomForestClassifier(n_estimators = 10, criterion = 'entropy', random_state = random_state)
    random_forest_classifier = RandomForestClassifier(n_estimators = 10, criterion = 'entropy', random_state = random_state, n_jobs = -1) #RCM137
    classify_start_time = time.time()    #RCM137
    classify_sub(random_forest_classifier, 
#RCM137          x_train, y_train,
                 X_train_scaled, y_train,           #RCM137
#RCM137          x_test, y_test,
                 X_test_scaled, y_test,             #RCM137
                 confusion_matrix_folder + prefix + '_cm_random_forest.csv',
                 summary_folder + prefix + '_summary_random_forest.csv',
                 'Random Forest',
                 verbose)
    elapsed_time = time.time() - classify_start_time                                                            #RCM137
    if verbose:                                                                                                 #RCM137
        print('random_forest_classifier execution time:', time.strftime("%H:%M:%S", time.gmtime(elapsed_time))) #RCM137

    # 7- Linear SVM 
#RCM137 svm_classifier = LinearSVC(random_state = random_state)
    svm_classifier = LinearSVC(max_iter = 10000000, random_state = random_state)
    classify_start_time = time.time()    #RCM137
    classify_sub(svm_classifier, 
#RCM137          x_train, y_train, 
                 X_train_scaled, y_train,               #RCM137
#RCM137          x_test, y_test, 
                 X_test_scaled, y_test,                 #RCM137
                 confusion_matrix_folder + prefix + '_cm_svm.csv', 
                 summary_folder + prefix + '_summary_svm.csv',
#RCM137          'SVM',
                 'Linear SVC',                          #RCM137
                 verbose)
    elapsed_time = time.time() - classify_start_time                                                                    #RCM137
    if verbose:                                                                                                         #RCM137
        print('svm_classifier execution time:', time.strftime("%H:%M:%S", time.gmtime(elapsed_time)))                   #RCM137

def summmarize_results ( y_true, y_predicted, classifier_used, output_directory, label_prefix, file_name, balance ):    #RCM137
    labels = ['Benign', 'Scan A', 'Scan Su', 'Spata', 'MQTT_BF']                                                        #RCM137
    disp = ConfusionMatrixDisplay.from_predictions ( y_true = y_true,                                                   #RCM137
                                                    y_pred = y_predicted,                                               #RCM137
                                                    display_labels = labels,                                            #RCM137
                                                    values_format = 'd',                                                #RCM137
                                                    cmap = 'Greys',                                                     #RCM137
                                                    colorbar = True )                                                   #RCM137

#    disp.plot()                                                                                                        #RCM137
    disp.ax_.set_title ("{} {} {}".format ( label_prefix, classifier_used, balance ))                                   #RCM137
    plt.savefig("{}/{}_{}_{}.png".format( output_directory, label_prefix, classifier_used, balance ), format = 'png')   #RCM137
#    plt.show()                                                                                                         #RCM137
    file_name.write (f"{label_prefix} {classifier_used} {balance}\n")                                                   #RCM137
    file_name.write ( classification_report ( y_true, y_predicted, target_names = labels, digits=5 ) )                  #RCM137

if __name__ == "__main__":
    start_time = time.time()    #RCM137

    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', type = int, default = 2)
    parser.add_argument('--output', default='Classification_Bi')
    parser.add_argument('--verbose', type = str2bool, default = True)
    parser.add_argument('--trace', type = str2bool, default = False)        #RCM137
    parser.add_argument('--filtered', type = str2bool, default = True)      #RCM137
    parser.add_argument('--balanced', type = str2bool, default = True)      #RCM137
    parser.add_argument('--nohot', type = str2bool, default = False)        #RCM137

    args = parser.parse_args()
    
    if not (args.mode == 0 or args.mode == 1 or args.mode == 2):    #RCM137
        print ('Please enter 0,1, or 2 for mode\n')                 #RCM137
        exit (-1)                                                   #RCM137
    if args.mode != 2:                                              #RCM137
        if args.output == 'Classification_Bi':                      #RCM137
            if args.mode == 0:                                      #RCM137
                args.output = 'Classification_Normal'               #RCM137
            elif args.mode == 1:                                    #RCM137
                args.output = 'Classification_Uni'                  #RCM137

    import sklearn                                                  #RCM137
    if args.verbose:                                                #RCM137
        print("System Version: ", sys.version)                      #RCM137
        print("Pandas: ", pd.__version__)                           #RCM137
        print("numpy: ", np.__version__)                            #RCM137
        print("sklearn: ", sklearn.__version__)                     #RCM137
        print("System Information: ", sys.version_info)             #RCM137

    for slice_number in range(10):
#    for slice_number in range(1):      #RCM137
        prefix = ''
        if args.mode == 1:
            prefix = 'uniflow_' 
        elif args.mode == 2:
            prefix = 'biflow_'
        
        if args.verbose:
            print ('Starting Slice #: {}'.format(slice_number))
            print ('Start Classification')
            
        random_state = 0
        folder_name = '{}_{}/'.format(args.output, slice_number)
        
        if os.path.isdir(folder_name) == False:
            os.mkdir(folder_name)
            
        output_directory = args.output                      #RCM137
        if os.path.isdir ( output_directory ) == False:     #RCM137
            os.mkdir ( output_directory )                   #RCM137
            
#RCM137 x, y = load_file(prefix + 'normal.csv', 
#RCM137                   args.mode, 
#RCM137                   0, 0, 
#RCM137                   folder_name, 
#RCM137                   slice_number,
#RCM137                   args.verbose)

        if args.mode == 0:                                  #RCM137
            if args.filtered:                               #RCM137
                prefix = 'filtered_'                        #RCM137
            else:                                           #RCM137
                prefix = 'preprocessed_'                    #RCM137
            
        x, y = load_file (path = prefix + 'normal.csv',     #RCM137
                          mode = args.mode,                 #RCM137
                          is_attack = 0,                    #RCM137
                          label = 0,                        #RCM137
                          folder_name = folder_name,        #RCM137
                          sliceno = slice_number,           #RCM137
                          verbose = args.verbose,           #RCM137
                          trace = args.trace,               #RCM137
                          balanced = args.balanced,         #RCM137
                          NoHot = args.nohot)               #RCM137
           
        if args.trace:                                                #RCM137
            sys.stderr.write (f"{prefix}normal x shape: {x.shape}\n") #RCM137
            sys.stderr.write (f"{prefix}normal y shape: {y.shape}\n") #RCM137
        if args.mode == 0:                                            #RCM137
            prefix = ''                                               #RCM137

#RCM137 x_temp, y_temp = load_file(prefix + 'scan_A.csv', 
#RCM137                             args.mode, 
#RCM137                             1, 1, 
#RCM137                             folder_name,
#RCM137                             slice_number,
#RCM137                             args.verbose)
        
        if args.mode == 0:                                  #RCM137
            if args.filtered:                               #RCM137
                prefix = 'filtered_'                        #RCM137

        x_temp, y_temp = load_file(path = prefix + 'scan_A.csv',    #RCM137
                                   mode = args.mode,                #RCM137
                                   is_attack = 1,                   #RCM137
                                   label = 1,                       #RCM137
                                   folder_name = folder_name,       #RCM137
                                   sliceno = slice_number,          #RCM137
                                   verbose = args.verbose,          #RCM137
                                   trace = args.trace,              #RCM137
                                   balanced = args.balanced,        #RCM137
                                   NoHot = args.nohot)              #RCM137
       
        if args.trace:                                                      #RCM137
            sys.stderr.write (f"{prefix}scan_A x shape: {x_temp.shape}\n")  #RCM137
            sys.stderr.write (f"{prefix}scan_A y shape: {y_temp.shape}\n")  #RCM137
        if args.mode == 0:                                                  #RCM137
            prefix = ''                                                     #RCM137

        x = np.concatenate((x, x_temp), axis = 0)
        y = np.append(y, y_temp)
        del x_temp, y_temp
        
            
#RCM137 x_temp, y_temp = load_file(prefix + 'scan_sU.csv', 
#RCM137                             args.mode, 
#RCM137                             1, 2, 
#RCM137                             folder_name,
#RCM137                             slice_number,
#RCM137                             args.verbose)
        
        if args.mode == 0:                                  #RCM137
            if args.filtered:                               #RCM137
                prefix = 'filtered_'                        #RCM137

        x_temp, y_temp = load_file(path = prefix + 'scan_sU.csv',   #RCM137
                                   mode = args.mode,                #RCM137
                                   is_attack = 1,                   #RCM137
                                   label = 2,                       #RCM137
                                   folder_name = folder_name,       #RCM137
                                   sliceno = slice_number,          #RCM137
                                   verbose = args.verbose,          #RCM137
                                   trace = args.trace,              #RCM137
                                   balanced = args.balanced,        #RCM137
                                   NoHot = args.nohot)              #RCM137
        
        if args.trace:                                                      #RCM137
            sys.stderr.write (f"{prefix}scan_sU x shape: {x_temp.shape}\n") #RCM137
            sys.stderr.write (f"{prefix}scan_sU y shape: {y_temp.shape}\n") #RCM137
        if args.mode == 0:                                                  #RCM137
            prefix = ''                                                     #RCM137

        x = np.concatenate((x, x_temp), axis = 0)
        y = np.append(y, y_temp)
        del x_temp, y_temp
            
#RCM137 x_temp, y_temp = load_file(prefix + 'sparta.csv', 
#RCM137                             args.mode, 
#RCM137                             1, 3,
#RCM137                             folder_name,
#RCM137                             slice_number,
#RCM137                             args.verbose)
        
        if args.mode == 0:                                  #RCM137
            if args.filtered:                               #RCM137
                prefix = 'filtered_'                        #RCM137
            else:                                           #RCM137
                prefix = 'preprocessed_'                    #RCM137

        x_temp, y_temp = load_file(path = prefix + 'sparta.csv',    #RCM137
                                   mode = args.mode,                #RCM137
                                   is_attack = 1,                   #RCM137
                                   label = 3,                       #RCM137
                                   folder_name = folder_name,       #RCM137
                                   sliceno = slice_number,          #RCM137
                                   verbose = args.verbose,          #RCM137
                                   trace = args.trace,              #RCM137
                                   balanced = args.balanced,        #RCM137
                                   NoHot = args.nohot)              #RCM137

        if args.trace:                                                      #RCM137
            sys.stderr.write (f"{prefix}sparta x shape: {x_temp.shape}\n")  #RCM137
            sys.stderr.write (f"{prefix}sparta y shape: {y_temp.shape}\n")  #RCM137
        if args.mode == 0:                                                  #RCM137
            prefix = ''                                                     #RCM137

        x = np.concatenate((x, x_temp), axis = 0)
        y = np.append(y, y_temp)
        del x_temp, y_temp

#RCM137 x_temp, y_temp = load_file(prefix + 'mqtt_bruteforce.csv', 
#RCM137                             args.mode,
#RCM137                             1, 4, 
#RCM137                             folder_name,
#RCM137                             slice_number,
#RCM137                             args.verbose)
        
        if args.mode == 0:                                  #RCM137
            if args.filtered:                               #RCM137
                prefix = 'filtered_'                        #RCM137
            else:                                           #RCM137
                prefix = 'preprocessed_'                    #RCM137

        x_temp, y_temp = load_file(path = prefix + 'mqtt_bruteforce.csv',   #RCM137
                                   mode = args.mode,                        #RCM137
                                   is_attack = 1,                           #RCM137
                                   label = 4,                               #RCM137
                                   folder_name = folder_name,               #RCM137
                                   sliceno = slice_number,                  #RCM137
                                   verbose = args.verbose,                  #RCM137
                                   trace = args.trace,                      #RCM137
                                   balanced = args.balanced,         #RCM137
                                   NoHot = args.nohot)               #RCM137
        
        if args.trace:                                                                #RCM137
            sys.stderr.write (f"{prefix}mqtt_bruteforce x shape: {x_temp.shape}\n")   #RCM137
            sys.stderr.write (f"{prefix}mqtt_bruteforce y shape: {y_temp.shape}\n")   #RCM137
        if args.mode == 0:                                                            #RCM137
            prefix = ''                                                               #RCM137

        x = np.concatenate((x, x_temp), axis = 0)
        y = np.append(y, y_temp)
        del x_temp, y_temp

        x_train, x_test, y_train, y_test = train_test_split(x, y, 
                                                            test_size = 0.25,
                                                            random_state = 42)
        
        classify(random_state, x_train, y_train, x_test, y_test, 
                 folder_name, "slice_{}_no_cross_validation".format(slice_number), args.verbose)
       
        kfold = StratifiedKFold(n_splits = 5, shuffle = True, random_state = 0)
        
        counter = 0
        for train, test in kfold.split(x, y):
            classify(random_state, x[train], y[train], x[test], y[test], 
                     folder_name, "slice_{}_k_{}".format(slice_number, counter), args.verbose)
            counter += 1
            
        del x
        del y
        del x_train
        del x_test
        del y_train
        del y_test

    if args.mode == 0:                          #RCM137
        if args.filtered:                       #RCM137
            label_prefix = 'Packet Filtered'    #RCM137
        else:                                   #RCM137
            label_prefix = 'Packet'             #RCM137
    elif args.mode == 1:                        #RCM137
        label_prefix = 'Uniflow'                #RCM137
    elif args.mode == 2:                        #RCM137
        label_prefix = 'Biflow'                 #RCM137

    if args.nohot:                              #RCM137
        label_prefix = 'NoHot_' + label_prefix  #RCM137

    if args.balanced:                           #RCM137
        balance = 'Balanced'                    #RCM37
    else:                                       #RCM137
        balance = 'Unbalanced'                  #RCM137

    classification_file_name = output_directory + '/' + label_prefix + '_Classification_Report_' + balance   #RCM137
    classification_file = open ( classification_file_name, "w" )                                             #RCM137
   
    summmarize_results ( logistic_y_true, logistic_y_predictions, 'Logistic', output_directory, label_prefix, classification_file, balance )                    #RCM137
    del logistic_y_true                                                                                                                                         #RCM137
    del logistic_y_predictions                                                                                                                                  #RCM137
    summmarize_results ( knn_y_true, knn_y_predictions, 'KNN', output_directory, label_prefix, classification_file, balance )                                   #RCM137
    del knn_y_true                                                                                                                                              #RCM137
    del knn_y_predictions                                                                                                                                       #RCM137
    summmarize_results ( rbf_y_true, rbf_y_predictions, 'RBF', output_directory, label_prefix, classification_file, balance )                                   #RCM137
    del rbf_y_true                                                                                                                                              #RCM137
    del rbf_y_predictions                                                                                                                                       #RCM137
    summmarize_results ( naive_y_true, naive_y_predictions, 'Naive', output_directory, label_prefix, classification_file, balance )                             #RCM137
    del naive_y_true                                                                                                                                            #RCM137
    del naive_y_predictions                                                                                                                                     #RCM137
    summmarize_results ( decision_tree_y_true, decision_tree_y_predictions, 'Decision Tree', output_directory, label_prefix, classification_file, balance )     #RCM137
    del decision_tree_y_true                                                                                                                                    #RCM137
    del decision_tree_y_predictions                                                                                                                             #RCM137
    summmarize_results ( random_forest_y_true, random_forest_y_predictions, 'Random Forest', output_directory, label_prefix, classification_file, balance )     #RCM137
    del random_forest_y_true                                                                                                                                    #RCM137
    del random_forest_y_predictions                                                                                                                             #RCM137
    summmarize_results ( linear_svc_y_true, linear_svc_y_predictions, 'Linear SVC', output_directory, label_prefix, classification_file, balance )              #RCM137
    del linear_svc_y_true                                                                                                                                       #RCM137
    del linear_svc_y_predictions                                                                                                                                #RCM137
    classification_file.close()                                                                                                                                 #RCM137
    
    elapsed_time = time.time() - start_time                                             #RCM137
    if args.verbose:                                                                    #RCM137
        print('Execution time:', time.strftime("%H:%M:%S", time.gmtime(elapsed_time)))  #RCM137
